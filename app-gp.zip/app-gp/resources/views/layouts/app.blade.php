<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>@yield('title', config('app.name'))</title>
        <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
        <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
    </head>
    <body>
        <header class="bg-gradient-to-r from-yellow-300 to-yellow-500 text-center px-6 py-4">
            <nav class="md:flex md:justify-between md:items-center inline">
                @auth 
                    <div>
                        <a class="text-sm font-semibold uppercase" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            {{ Auth::user()->name }}
                        </a>
                    </div>
                    <div class="mt-8 md:mt-0 inline">
                        <div class="text-xs font-semibold text-white " aria-labelledby="navbarDropdown">
                            @yield('nav')

                            <a class="dropdown-item" href="{{ route('logout') }}"
                               onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                                {{ __('Logout') }}
                            </a>
                            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                @csrf
                            </form>
                        </div>
                    </div>
                @endauth
            </nav>
        </header>
        <main>
            @yield('content')
        </main>
    </body>
</html>
