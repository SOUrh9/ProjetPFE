<!DOCTYPE html>
<html lang="{{ app()-> getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>@yield('title', config('app.name'))</title>
        <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
        <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
        
        
    </head> 
    <body class="min-h-screen">
        <main class="py-10 flex flex-col justify-between items-center">
            @yield('content')
        </main>
        
        <footer class="py-10 flex flex-col justify-between items-center">
            <p class="text-gray-400">&copy; Copyright {{ date('Y')}} </p>
        </footer>
    </body>
</html>
