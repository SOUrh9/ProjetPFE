@extends('layouts.app')

@section('title', 'Etude | '.config('app.name'))



@section('content')
    
    <div class="relative  h-full my-5">
        <h1 class="text-3xl font-serif tracking-tighter mb-5">Liste des études</h1>
        <table class="ml-2 table-fixed ">
            <thead class="bg-yellow-500 ">
                <th class="border-2 border-white w-1/4 ">Nom</th>
                <th class="border-2 border-white w-1/6">Wilaya</th>
                <th class="border-2 border-white w-1/6">Type</th>
                <th class="border-2 border-white w-1/4">Prestataire</th>
                <th class="border-2 border-white w-1/2">Date</th>
            </thead>
            <tbody>
            
                <div>
                    <tr class="text-center py-6">
                        <td class=" border-2 border-gray-300 w-1/4 ">{{ $etude->nom }}</td>
                        <td class=" border-2 border-gray-300 w-1/6 ">{{ $etude->region->wilaya }}</td>
                        <td class=" border-2 border-gray-300 w-1/6 "> {{ $etude->type }}</td>
                        <td class=" border-2 border-gray-300 w-1/4 ">{{ $etude->prestataire->nom }}</td>
                        <td class=" border-2 border-gray-300 w-1/2 "> {{ $etude->date }}</td>
                    </tr>
                </div>

            
            </tbody>
        </table>
        <div class="my-5 ml-10">
            <a href="/etude" >&#8477;&#8519;v&#8519;n&#8520;r</a>
        </div>
    </div>
@endsection
