@extends('layouts.index')

@section('title', 'Projet | '.config('app.name'))

@section('nav')
    <a href="/admin/dashboard" class="dropdown-item mr-2 ml-2">    
        {{ __('Tables de bord') }}
    </a>
    <a class="dropdown-item mr-2 ml-2" href="/etude">
        {{ __('Liste des études') }}
    </a>
@endsection

@section('content')
    
    <div class="relative w-full h-full my-5">
        <h1 class="text-3xl font-serif tracking-tighter mb-5">Liste des projets en cours</h1>
        <table class="ml-2 table-fixed ">
            <thead class="bg-yellow-500 ">
                <th class="border-2 border-white w-1/4 ">Nom</th>
                <th class="border-2 border-white w-1/4">Wilaya</th>
                <th class="border-2 border-white w-1/4">Prestataire</th>
                <th class="border-2 border-white w-1/2">Description</th>
                
            </thead>
            <tbody>
            @foreach ($projects as $project)
                <div>
                    <tr>
                        <td class="text-center border-2 border-gray-300 w-1/4 ">
                            <a href="/projects/{{ $project->nom }}">{{ $project->nom }}</a>
                        </td>
                        <td class="text-center border-2 border-gray-300 w-1/4 ">
                            <a href="/region/{{ $project->region->id }}">{{ $project->region->wilaya }}</a>
                        </td>
                        <td class="text-center border-2 border-gray-300 w-1/4 ">
                            <a href="/prestataire/{{ $project->prestataire->id }}">{{ $project->prestataire->nom }}</a>
                        </td>
                        <td class="border-2 border-gray-300 w-1/4 leading-relaxed "> {{ $project->description }}</td>
                        
                    </tr>
                </div>

            @endforeach
            </tbody>
        </table>
    </div>
@endsection
