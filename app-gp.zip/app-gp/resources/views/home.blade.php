@extends('layouts.app')

@section('title', 'Acceuil | '.config('app.name'))

@section('nav')
    <a href="/admin/dashboard" class="dropdown-item mr-2 ml-2">    
        {{ __('Tables de bord') }}
    </a>
@endsection

@section('content')
    <div class="my-52 flex flex-col justify-between items-center">
        <div class="text-9xl">{{ __('Acceuil') }}</div>
        <div class="text-lg">
            @if (session('status'))
                <div class="" role="">
                    {{ session('status') }}
                </div>
            @endif

            {{ __('Vous êtes connecté !') }}
         </div>
    </div>
@endsection
