@extends('layouts.app')

@section('title', 'Tableau de bord | '.config('app.name'))

@section('nav')
    <a href="profile" class="dropdown-item mr-2 ml-2">    
        {{ __('profile') }}
    </a>
    <a class="dropdown-item mr-2 ml-2" href="/etude">
        {{ __('Liste des études') }}
    </a>
    <a class="dropdown-item mr-2 ml-2" href="/project">
        {{ __('Liste des projets') }}
    </a>
@endsection

@section('content')
    <div class="my-52 flex flex-col justify-between items-center">         
        <div class="text-9xl">{{ __('Tableau de bord') }}</div>
        <div class="text-2xl">
            @if (session('status'))
                <div class="" role="1">
                    {{ session('status') }}
                </div>
            @endif
                    
            {{ __('Vous êtes connecté !') }}
        </div>
    </div>
@endsection
