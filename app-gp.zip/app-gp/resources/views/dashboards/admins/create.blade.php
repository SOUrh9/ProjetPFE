@extends('layouts.app')

@section('title', 'Ajout Projet | '.config('app.name'))


@section('nav')
    <a href="profile" class="dropdown-item mr-2 ml-2">    
        {{ __('profile') }}
    </a>
@endsection


@section('content')
    <h1 class="mt-4 text-3xl tracking-wide font-medium text-yellow-500 mb-6 text-center">Création d'un projet</h1>
    <form class="w-full max-w-sm mx-auto rounded-lg border shadow-md p-5 mb-5" action="/admin" method="post"> 
      @if(Session::get('success'))
            <div class="text-center bg-green-100 alert">
                {{ Session::get('success') }}
            </div>
      @endif
      @if(Session::get('error'))
            <div class="text-center bg-red-100 alert">
                {{ Session::get('error') }}
            </div>
      @endif 
        @csrf
        
      <!-- nom --> 
        <div class="mb-4">
            <label for="name" class="block font-semibold text-gray-700 mb-2">{{ __('Nom') }}</label>
            <input id="name" type="text" 
                    class="shadow border rounded w-full p-2 @error('name') is-invalid @enderror" 
                    name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>
            @error('name')
                <span class="text-red-700 text-base invalid-feedback" role="alert">
                    {{ $message }}
                </span>
            @enderror    
        </div>


      <!-- description --> 
        <div class="mb-4">
            <label for="description" class="block font-semibold text-gray-700 mb-2">{{ __('Description') }}</label>
            <input id="description" type="description" 
                    class="shadow border rounded w-full p-2 @error('description') is-invalid @enderror" 
                    name="description" value="{{ old('description') }}" required autocomplete="description">
            @error('description')
                <span class="text-red-700 text-base invalid-feedback" role="alert">
                    {{ $message }}
                </span>
            @enderror            
        </div>


       
      <!-- type > 
        <div class="mb-4">
            <input class="ml-14" type="radio" name="Type" id="integrer" >Intégré 
            <input class="ml-10" type="radio" name="Type" id="specifique">Spécifique    
        </div-->

        <div class="mb-4">
            <label for="type" class="block font-semibold text-gray-700 mb-2">{{ __('type') }}</label>
            <input id="type" type="type" 
                    class="shadow border rounded w-full p-2 @error('type') is-invalid @enderror" 
                    name="type" value="{{ old('type') }}" required autocomplete="type">
            @error('type')
                <span class="text-red-700 text-base invalid-feedback" role="alert">
                    {{ $message }}
                </span>
            @enderror            
        </div>

        
      <!-- date_debut --> 
        <div class="my-2">
            <label for="date_debut" class="block font-semibold text-gray-700 mb-2">{{ __('Date début') }}</label>
            <input id="date_debut" type="date_debut" 
                    class="shadow border rounded w-full p-2 @error('date_debut') is-invalid @enderror" 
                    name="date_debut" value="{{ old('date_debut') }}" required autocomplete="new-date_debut">
            @error('date_debut')
                <span class="text-red-700 text-base invalid-feedback" role="alert">
                    {{ $message }}
                </span>
            @enderror           
        </div>



      <!-- date_fin --> 
       <div class="my-2">
            <label for="date_fin" class="block font-semibold text-gray-700 mb-2">{{ __('Date fin') }}</label>
            <input id="date_fin" type="date_fin" 
                    class="shadow border rounded w-full p-2 @error('date_fin') is-invalid @enderror" 
                    name="date_fin" value="{{ old('date_fin') }}" required autocomplete="new-date_fin">
            @error('date_fin')
                <span class="text-red-700 text-base invalid-feedback" role="alert">
                    {{ $message }}
                </span>
            @enderror           
        </div>

     
     
      <!-- region --> 
        <div class="my-6">
            <label for="region" class="block font-semibold text-gray-700 mb-2">{{ __('Region') }}</label>
            <select name="region" id="region"> 

                @foreach(\App\Models\Region::all() as $region)
                    <option value="{{ $region->id }}"
                        {{ old('region_id') == $region->id ? 'selected' : ''}}>{{ ucwords($region->nom) }}</option>  
                @endforeach
                
            </select>    
        </div>

        
    
      <!-- prestataire --> 
        <div class="mb-8">
            <label for="prestataire" class="block font-semibold text-gray-700 mb-2">{{ __('Prestataire') }}</label>
            <select name="prestataire" id="prestataire"> 
               
                @foreach(\App\Models\Prestataire::all() as $prestataire)
                    <option value="{{ $prestataire->id }}"
                        {{ old('prestataire_id') == $prestataire->id ? 'selected' : ''}}>{{ ucwords($prestataire->nom) }}</option>  
                @endforeach
                
            </select>    
        </div>

        
      <!-- boutton d'enregistrement --> 
        <button type="submit" class="mx-32 my-2 bg-yellow-500 text-white hover:bg-yellow-700 transition ease-in-out duration-500 rounded-md shadow-md block px-6 py-2">
            {{ __('Créer') }}
        </button>
    </form>
@endsection
