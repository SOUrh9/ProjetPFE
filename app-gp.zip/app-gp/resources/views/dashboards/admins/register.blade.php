@extends('layouts.app')

@section('title', 'Registre | '.config('app.name'))

@section('nav')
    <a href="profile" class="dropdown-item mr-2 ml-2">    
        {{ __('profile') }}
    </a>
@endsection

@section('content')
    <h1 class="mt-4 tracking-wide font-medium text-3xl text-yellow-500 mb-6 text-center">Completez les informations</h1>
                
    <form method="POST" action="{{ route('register') }}" class="w-full max-w-sm mx-auto rounded-lg border shadow-md p-5 mb-5">
        @if(Session::get('success'))
            <div class="text-center bg-green-100 alert">
                {{ Session::get('success') }}
            </div>
        @endif
        @if(Session::get('error'))
            <div class="text-center bg-red-100 alert">
                {{ Session::get('error') }}
            </div>
        @endif  
      
    @csrf
        
    <!-- nom --> 
        <div class="mb-4">
            <label for="name" class="block font-semibold text-gray-700 mb-2">{{ __('Nom') }}</label>
            <input id="name" type="text" class="shadow border rounded w-full p-2 @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>
            @error('name')
                <span class="text-red-700 text-base invalid-feedback" role="alert">
                    {{ $message }}
                </span>
            @enderror    
        </div>
    <!-- email --> 
        <div class="mb-4">
            <label for="email" class="block font-semibold text-gray-700 mb-2">{{ __('Addresse mail') }}</label>
            <input id="email" type="email" class="shadow border rounded w-full p-2 @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email">
            @error('email')
                <span class="text-red-700 text-base invalid-feedback" role="alert">
                    {{ $message }}
                </span>
            @enderror            
        </div>
       <!-- role --> 
        <div class="mb-4">
            <label for="role" class="block font-semibold text-gray-700 mb-2">{{ __('Role') }}</label>
            <input id="role" 
                    type="text" 
                    class="shadow border rounded w-full p-2 @error('role') is-invalid @enderror" 
                    name="role" value="{{ old('role') }}"
                    required autocomplete="role" autofocus>
            @error('role')
                <span class="text-red-700 text-base invalid-feedback" role="alert">
                    {{ $message }}
                </span>
            @enderror    
        </div>
    <!-- mot de passe --> 
        <div class="mb-4">
            <label for="password" class="block font-semibold text-gray-700 mb-2">{{ __('Mot de passe') }}</label>
            <input id="password" type="password" class="shadow border rounded w-full p-2 @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">
            @error('password')
                <span class="text-red-700 text-base invalid-feedback" role="alert">
                    {{ $message }}
                </span>
            @enderror           
        </div>
    <!-- confirmation mot de passe --> 
        <div class="mb-8">
            <label for="password-confirm" class="block font-semibold text-gray-700 mb-2">{{ __('Confirmer le mot de passe') }}</label>           
            <input id="password-confirm" type="password" class="shadow border rounded w-full p-2 " name="password_confirmation" required autocomplete="new-password">            
        </div>

     <!-- boutton d'enregistrement --> 
        <button type="submit" class="mx-24 my-2 bg-yellow-500 text-white hover:bg-yellow-700 transition ease-in-out duration-500 rounded-md shadow-md block px-4 py-2">
            {{ __('Créer compte') }}
        </button>
        
    </form>
@endsection

