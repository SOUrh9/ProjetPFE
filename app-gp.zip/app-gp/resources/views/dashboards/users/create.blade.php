@extends('layouts.app')

@section('title', 'Ajout expérience | '.config('app.name'))


@section('nav')
    <a href="profile" class="dropdown-item mr-2 ml-2">    
        {{ __('profile') }}
    </a>
@endsection

@section('content')
    <div class="py-20">
        <h1 class="mt-4 text-3xl tracking-wide font-medium text-yellow-500 mb-6 text-center capitalize">ajouter expérience</h1>
                
        <form method="POST" action="/user" class="w-full max-w-sm mx-auto rounded-lg border shadow-md p-5 mb-5">
            @if(Session::get('success'))
                <div class="text-center bg-green-100 alert">
                    {{ Session::get('success') }}
                </div>
            @endif
            @if(Session::get('error'))
                <div class="text-center bg-red-100 alert">
                    {{ Session::get('error') }}
                </div>
            @endif  
                  
           @csrf
                    
         <!-- experience --> 
            <div class="mb-8">
                <label for="experience" class="block font-semibold text-gray-700 mb-2">{{ __('Expérience') }}</label>
                <textarea id="experience" type="text" class="shadow border rounded w-full p-2 @error('experience') is-invalid @enderror" 
                        name="experience"    
                        required autocomplete="name" autofocus
                        placeholder="Ajouter votre expérience"></textarea>
                @error('experience')
                    <span class="text-red-700 text-base invalid-feedback" role="alert">
                                {{ $message }}
                            </span>
                        @enderror    
            </div>
                
         <!-- boutton d'ajout --> 
            <button type="submit" class="mx-32 my-1 bg-yellow-500 text-white hover:bg-yellow-700 transition ease-in-out duration-500 rounded-md shadow-md block px-4 py-2">
                {{ __('Ajouter') }}
            </button>
                    
        </form>
    </div>
@endsection