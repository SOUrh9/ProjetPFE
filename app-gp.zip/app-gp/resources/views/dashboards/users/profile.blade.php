@extends('layouts.app')

@section('title', 'Profile | '.config('app.name'))

@section('titre_page','Gestion des études et projets')

@section('nav')
    <a href="dashboard" class="dropdown-item mr-2 ml-2">    
        {{ __('Tableau de bord') }}
    </a>
    <a href="create" class="dropdown-item mr-2 ml-2">    
        {{ __('Ajouter expérience') }}
    </a>
@endsection

@section('content')
    <div class="my-52 flex flex-col justify-between items-center ">         
        <div class="text-9xl">{{ __('Profile') }}</div>
        <div class="text-lg">
            @if (session('status'))
                <div class="" role="2">
                    {{ session('status') }}
                </div>
            @endif
                    
            {{ __('Vous êtes connecté !') }}
        </div>
    </div>
@endsection
