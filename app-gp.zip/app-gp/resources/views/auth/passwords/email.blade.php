@extends('layouts.base')

@section('content')
    <h1 class="text-3xl text-yellow-500 mb-6 mt-20 text-center">{{ __('Reset Password') }}</h1>

    <div class="w-full max-w-sm mx-auto rounded-lg border shadow-md p-5 mb-5">
        @if (session('status'))
            <div class="text-center bg-green-100 alert" role="alert">
                 {{ session('status') }}
            </div>
        @endif

        <form method="POST" action="{{ route('password.email') }}">
            @csrf

            <div class="">
                <label for="email" class="block font-semibold text-gray-700 mb-2">{{ __('E-Mail Address') }}</label>

                <div class="col-md-6">
                    <input id="email" type="email" class="shadow border rounded w-full @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                    @error('email')
                        <span class="text-red-700 text-base invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>

            <button type="submit" class="bg-yellow-500 text-white hover:bg-yellow-700 transition ease-in-out duration-500 rounded-md shadow-md w-full block px-4 py-2 mt-3">
                {{ __('Envoyer le lien') }}
            </button>
               
        </form>
    </div>
@endsection
