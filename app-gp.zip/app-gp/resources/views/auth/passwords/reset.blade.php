@extends('layouts.base')

@section('title', 'Réinitialisation | '.config('app.name'))

@section('content')
        <h1 class="text-3xl text-yellow-500 mb-6 text-center">{{ __('Réinitialiser le mot de passe') }}</h1>
        <form method="POST" action="{{ route('password.update') }}">
            @csrf

            <input type="hidden" name="token" value="{{ $token }}">

            <div class="">
                <label for="email" class="">{{ __('Adresse e-mail') }}</label>

                <div class="">
                    <input id="email" type="email" class=" @error('email') is-invalid @enderror" name="email" value="{{ $email ?? old('email') }}" required autocomplete="email" autofocus>

                     @error('email')
                         <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>

            <div class="">
                <label for="password" class="">{{ __('Mot de passe') }}</label>
                <div class="">
                    <input id="password" type="password" class=" @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                    @error('password')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                </div>
            </div>

            <div class="">
                <label for="password-confirm" class="">{{ __('Confirm Password') }}</label>

                <div class="col-md-6">
                    <input id="password-confirm" type="password" class="" name="password_confirmation" required autocomplete="new-password">
                        </div>
                    </div>

                <div class="">
                    <div class="">
                        <button type="submit" class="">
                            {{ __('Réinitialiser') }}
                        </button>
                    </div>
                </div>
            </div>
        </form>
@endsection
