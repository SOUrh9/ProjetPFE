@extends('layouts.base')

@section('title', 'Connexion | '.config('app.name'))

@section('content')
    <h1 class="text-3xl tracking-wide font-medium text-yellow-500 mt-20 mb-10 text-center">Connexion</h1>
    <form method="POST" action="{{ route('login') }}" class="w-full max-w-sm mx-auto rounded-lg border shadow-md p-5 mb-5">
        @csrf
     <!-- mail -->
        <div class="mb-4">
            <div class="relative">
                <label for="email" class="mr-10"><i class="fas fa-user"></i></label>
                <input class="shadow border rounded w-full p-2" id="email" type="email" placeholder="email" class="l @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
                @error('email')
                    <span class="text-red-400" role="alert">
                        <span>{{ $message }}</span>
                    </span>
                @enderror
        </div>
          

     <!-- mot de passe  -->
        <div class="mb-4">
            <label for="password" class=""><i class="fas fa-key"></i></label>
            <input class="shadow border rounded w-full p-2" id="password" placeholder="************" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">
                @error('password')
                    <span class="text-red-600" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
        </div>

     <!-- boutton de connexion-->
        <button type="submit" class="mx-24 my-1 bg-yellow-500 text-white hover:bg-yellow-700 transition ease-in-out duration-500 rounded-md shadow-md block px-4 py-2">Se connecter</button>
        <!--@if (Route::has('password.request'))
            a class="mx-2" href="{{ route('password.request') }}">
                {{ __('Mot de passe oublier?') }}
            </a
        @endif-->

    </form>
@endsection
