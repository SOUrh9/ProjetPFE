@extends('layouts.index')

@section('title', 'Etude | '.config('app.name'))

@section('nav')
    <a href="/admin/dashboard" class="dropdown-item mr-2 ml-2">    
        {{ __('Tables de bord') }}
    </a>
    <a class="dropdown-item mr-2 ml-2" href="/project">
        {{ __('Liste des projets') }}
    </a>
@endsection

@section('content')
    
    <div class="relative w-full h-full my-5">
        <h1 class="text-3xl font-serif tracking-tighter mb-5">Liste des études</h1>
        <table class="ml-2 table-fixed ">
            <thead class="bg-yellow-500">
                <th class="border-2 border-white w-1/4 ">Nom</th>
                <th class="border-2 border-white w-1/4">Type</th>
                <th class="border-2 border-white w-1/4">wilaya</th>                
            </thead>
            <tbody>
            @foreach ($etudes as $etude)
                <div class="">
                    <tr>
                        <td class="text-center border-2 border-gray-300 w-1/4 ">
                            <a href="/etudes/{{ $etude->nom }}">{{ $etude->nom }}</a>
                        </td>
                        <td class="text-center border-2 border-gray-300 w-1/4 "> {{ $etude->type }}</td>
                        <td class="text-center border-2 border-gray-300 w-1/4 ">
                            <a href="/region/{{ $etude->region->id }}">{{ $etude->region->wilaya }}</a>
                        </td>
                    </tr>
                </div>

            @endforeach
            </tbody>
        </table>
    </div>
@endsection
