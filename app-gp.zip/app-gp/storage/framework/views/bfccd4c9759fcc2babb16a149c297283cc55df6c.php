<?php $__env->startSection('title', 'Acceuil | '.config('app.name')); ?>

<?php $__env->startSection('nav'); ?>
    <a href="/admin/dashboard" class="dropdown-item mr-2 ml-2">    
        <?php echo e(__('Tables de bord')); ?>

    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="my-52 flex flex-col justify-between items-center">
        <div class="text-9xl"><?php echo e(__('Acceuil')); ?></div>
        <div class="text-lg">
            <?php if(session('status')): ?>
                <div class="" role="">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <?php echo e(__('Vous êtes connecté !')); ?>

         </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app-gp\resources\views/home.blade.php ENDPATH**/ ?>