

<?php $__env->startSection('title', 'Ajout Compte | '.config('app.name')); ?>


<?php $__env->startSection('nav'); ?>
    <a href="profile" class="dropdown-item mr-2 ml-2">    
        <?php echo e(__('profile')); ?>

    </a>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    
    <form class="w-full max-w-sm mx-auto rounded-lg border shadow-md p-5 mb-5" action="/dashboards/admins" method="POst">
        <?php if(Session::get('success')): ?>
            <div class="text-center bg-green-100 alert">
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(Session::get('error')): ?>
            <div class="text-center bg-red-100 alert">
                <?php echo e(Session::get('error')); ?>

            </div>
        <?php endif; ?>  
      
        <?php echo csrf_field(); ?>
        
    <!-- nom --> 
        <div class="mb-4">
            <label for="name" class="block font-semibold text-gray-700 mb-2"><?php echo e(__('Nom')); ?></label>
            <input id="name" type="text" 
                    class="shadow border rounded w-full p-2 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                    name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red-700 text-base invalid-feedback" role="alert">
                    <?php echo e($message); ?>

                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
        </div>
    <!-- email --> 
        <div class="mb-4">
            <label for="email" class="block font-semibold text-gray-700 mb-2"><?php echo e(__('Addresse mail')); ?></label>
            <input id="email" type="email" 
                    class="shadow border rounded w-full p-2 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                    name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red-700 text-base invalid-feedback" role="alert">
                    <?php echo e($message); ?>

                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>            
        </div>
       <!-- role --> 
        <div class="mb-4">
            <label for="role" class="block font-semibold text-gray-700 mb-2"><?php echo e(__('Role')); ?></label>
            <input id="role" 
                    type="text" 
                    class="shadow border rounded w-full p-2 <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                    name="role" value="<?php echo e(old('role')); ?>"
                    required autocomplete="role" autofocus>
            <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red-700 text-base invalid-feedback" role="alert">
                    <?php echo e($message); ?>

                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
        </div>
    <!-- mot de passe --> 
        <div class="mb-4">
            <label for="password" class="block font-semibold text-gray-700 mb-2"><?php echo e(__('Mot de passe')); ?></label>
            <input id="password" type="password" 
                    class="shadow border rounded w-full p-2 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                    name="password" required autocomplete="new-password">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red-700 text-base invalid-feedback" role="alert">
                    <?php echo e($message); ?>

                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>           
        </div>
    <!-- confirmation mot de passe --> 
        <div class="mb-4">
            <label for="password-confirm" class="block font-semibold text-gray-700 mb-2"><?php echo e(__('Confirmer le mot de passe')); ?></label>           
            <input id="password-confirm" type="password" 
                    class="shadow border rounded w-full p-2 " 
                    name="password_confirmation" required autocomplete="new-password">            
        </div>

     <!-- boutton d'enregistrement --> 
        <button type="submit" class="bg-yellow-500 text-white hover:bg-yellow-700 transition ease-in-out duration-500 rounded-md shadow-md w-full block px-4 py-2 mt-3">
            <?php echo e(__('Créer compte')); ?>

        </button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app-gp\resources\views/dashboards/admins/store.blade.php ENDPATH**/ ?>