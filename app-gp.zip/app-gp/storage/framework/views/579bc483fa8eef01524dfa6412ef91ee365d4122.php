<!DOCTYPE html>
<html lang="<?php echo e(app()-> getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title><?php echo $__env->yieldContent('title', config('app.name')); ?></title>

        <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">

        <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
        
        
    </head> 
    <body >
        <main role="main">
            <header class="bg-gradient-to-r from-yellow-300 to-yellow-500 text-center px-6 py-4 text-center ">
                <nav class="md:flex md:justify-between md:items-center inline">
                    <?php if(auth()->guard()->check()): ?> 
                        <div>
                            <a class="text-sm font-semibold uppercase" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?>

                            </a>
                        </div>
                        <!-- barre de recherche -->
                        <div class="relative h-30px flex cursor-pointer bg-gray-50 mr-40 rounded-3xl items-center shadow-lg pl-2 pr-2">
                            <form method="GET" action="#">
                                <input class="outline-none border-none font-medium bg-transparent " 
                                        type="text" 
                                        name="search" 
                                        placeholder="Recherche.........." 
                                        value="<?php echo e(request('search')); ?>">
                                <i class="fas fa-search"></i>
                            </form>
                        </div>
                    
                        <div class="mt-8 md:mt-0 inline">
                            
                            <div class="text-xs font-semibold text-white " aria-labelledby="navbarDropdown">
                                <?php echo $__env->yieldContent('nav'); ?>
                                
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </div>
                    <?php endif; ?>
                </nav>
            </header>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        

    </body>
</html><?php /**PATH C:\xampp\htdocs\app-gp\resources\views/layouts/index.blade.php ENDPATH**/ ?>