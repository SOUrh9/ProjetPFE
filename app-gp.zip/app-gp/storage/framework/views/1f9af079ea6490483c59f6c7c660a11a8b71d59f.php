

<?php $__env->startSection('title', 'Etude | '.config('app.name')); ?>



<?php $__env->startSection('content'); ?>
    
    <div class="relative  h-full my-5">
        <h1 class="text-3xl font-serif tracking-tighter mb-5">Liste des études</h1>
        <table class="ml-2 table-fixed ">
            <thead class="bg-yellow-500 ">
                <th class="border-2 border-white w-1/4 ">Nom</th>
                <th class="border-2 border-white w-1/6">Wilaya</th>
                <th class="border-2 border-white w-1/6">Type</th>
                <th class="border-2 border-white w-1/4">Prestataire</th>
                <th class="border-2 border-white w-1/2">Date</th>
            </thead>
            <tbody>
            
                <div>
                    <tr class="text-center py-6">
                        <td class=" border-2 border-gray-300 w-1/4 "><?php echo e($etude->nom); ?></td>
                        <td class=" border-2 border-gray-300 w-1/6 "><?php echo e($etude->region->wilaya); ?></td>
                        <td class=" border-2 border-gray-300 w-1/6 "> <?php echo e($etude->type); ?></td>
                        <td class=" border-2 border-gray-300 w-1/4 "><?php echo e($etude->prestataire->nom); ?></td>
                        <td class=" border-2 border-gray-300 w-1/2 "> <?php echo e($etude->date); ?></td>
                    </tr>
                </div>

            
            </tbody>
        </table>
        <div class="my-5 ml-10">
            <a href="/etude" >&#8477;&#8519;v&#8519;n&#8520;r</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app-gp\resources\views/etude.blade.php ENDPATH**/ ?>