

<?php $__env->startSection('title', 'Etude | '.config('app.name')); ?>

<?php $__env->startSection('nav'); ?>
    <a href="/admin/dashboard" class="dropdown-item mr-2 ml-2">    
        <?php echo e(__('Tables de bord')); ?>

    </a>
    <a class="dropdown-item mr-2 ml-2" href="/project">
        <?php echo e(__('Liste des projets')); ?>

    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="relative w-full h-full my-5">
        <h1 class="text-3xl font-serif tracking-tighter mb-5">Liste des études</h1>
        <table class="ml-2 table-fixed ">
            <thead class="bg-yellow-500">
                <th class="border-2 border-white w-1/4 ">Nom</th>
                <th class="border-2 border-white w-1/4">Type</th>
                <th class="border-2 border-white w-1/4">wilaya</th>                
            </thead>
            <tbody>
            <?php $__currentLoopData = $etudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etude): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="">
                    <tr>
                        <td class="text-center border-2 border-gray-300 w-1/4 ">
                            <a href="/etudes/<?php echo e($etude->nom); ?>"><?php echo e($etude->nom); ?></a>
                        </td>
                        <td class="text-center border-2 border-gray-300 w-1/4 "> <?php echo e($etude->type); ?></td>
                        <td class="text-center border-2 border-gray-300 w-1/4 ">
                            <a href="/region/<?php echo e($etude->region->id); ?>"><?php echo e($etude->region->wilaya); ?></a>
                        </td>
                    </tr>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app-gp\resources\views/etudes.blade.php ENDPATH**/ ?>