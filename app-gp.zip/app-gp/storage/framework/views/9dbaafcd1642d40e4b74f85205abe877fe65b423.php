<?php $__env->startSection('title', 'Connexion | '.config('app.name')); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-3xl tracking-wide font-medium text-yellow-500 mt-20 mb-10 text-center">Connexion</h1>
    <form method="POST" action="<?php echo e(route('login')); ?>" class="w-full max-w-sm mx-auto rounded-lg border shadow-md p-5 mb-5">
        <?php echo csrf_field(); ?>
     <!-- mail -->
        <div class="mb-4">
            <div class="relative">
                <label for="email" class="mr-10"><i class="fas fa-user"></i></label>
                <input class="shadow border rounded w-full p-2" id="email" type="email" placeholder="email" class="l <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-400" role="alert">
                        <span><?php echo e($message); ?></span>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
          

     <!-- mot de passe  -->
        <div class="mb-4">
            <label for="password" class=""><i class="fas fa-key"></i></label>
            <input class="shadow border rounded w-full p-2" id="password" placeholder="************" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-600" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

     <!-- boutton de connexion-->
        <button type="submit" class="mx-24 my-1 bg-yellow-500 text-white hover:bg-yellow-700 transition ease-in-out duration-500 rounded-md shadow-md block px-4 py-2">Se connecter</button>
        <!--<?php if(Route::has('password.request')): ?>
            a class="mx-2" href="<?php echo e(route('password.request')); ?>">
                <?php echo e(__('Mot de passe oublier?')); ?>

            </a
        <?php endif; ?>-->

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app-gp\resources\views/auth/login.blade.php ENDPATH**/ ?>