

<?php $__env->startSection('title', 'Ajout expérience | '.config('app.name')); ?>


<?php $__env->startSection('nav'); ?>
    <a href="profile" class="dropdown-item mr-2 ml-2">    
        <?php echo e(__('profile')); ?>

    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="py-20">
        <h1 class="mt-4 text-3xl tracking-wide font-medium text-yellow-500 mb-6 text-center capitalize">ajouter expérience</h1>
                
        <form method="POST" action="/user" class="w-full max-w-sm mx-auto rounded-lg border shadow-md p-5 mb-5">
            <?php if(Session::get('success')): ?>
                <div class="text-center bg-green-100 alert">
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>
            <?php if(Session::get('error')): ?>
                <div class="text-center bg-red-100 alert">
                    <?php echo e(Session::get('error')); ?>

                </div>
            <?php endif; ?>  
                  
           <?php echo csrf_field(); ?>
                    
         <!-- experience --> 
            <div class="mb-8">
                <label for="experience" class="block font-semibold text-gray-700 mb-2"><?php echo e(__('Expérience')); ?></label>
                <textarea id="experience" type="text" class="shadow border rounded w-full p-2 <?php $__errorArgs = ['experience'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                        name="experience"    
                        required autocomplete="name" autofocus
                        placeholder="Ajouter votre expérience"></textarea>
                <?php $__errorArgs = ['experience'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-700 text-base invalid-feedback" role="alert">
                                <?php echo e($message); ?>

                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
            </div>
                
         <!-- boutton d'ajout --> 
            <button type="submit" class="mx-32 my-1 bg-yellow-500 text-white hover:bg-yellow-700 transition ease-in-out duration-500 rounded-md shadow-md block px-4 py-2">
                <?php echo e(__('Ajouter')); ?>

            </button>
                    
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app-gp\resources\views/dashboards/users/create.blade.php ENDPATH**/ ?>