<!DOCTYPE html>
<html lang="<?php echo e(app()-> getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo $__env->yieldContent('title', config('app.name')); ?></title>
        <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
        <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
        
        
    </head> 
    <body class="min-h-screen">
        <main class="py-10 flex flex-col justify-between items-center">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        
        <footer class="py-10 flex flex-col justify-between items-center">
            <p class="text-gray-400">&copy; Copyright <?php echo e(date('Y')); ?> </p>
        </footer>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\app-gp\resources\views/layouts/base.blade.php ENDPATH**/ ?>