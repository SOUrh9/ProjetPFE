

<?php $__env->startSection('title', 'Profile | '.config('app.name')); ?>

<?php $__env->startSection('nav'); ?>
    <a href="dashboard" class="dropdown-item mr-2 ml-2">    
        <?php echo e(__('Tableau de bord')); ?>

    </a>
    <a href="create" class="dropdown-item mr-2 ml-2">    
        <?php echo e(__('Ajouter projet')); ?>

    </a>
    <a href="register" class="dropdown-item mr-2 ml-2" > <?php echo e(__('Ajouter compte')); ?></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="my-52 flex flex-col justify-between items-center ">         
        <div class="text-9xl"><?php echo e(__('Profile')); ?></div>
        <div class="text-lg">
            <?php if(session('status')): ?>
                <div class="" role="1">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
                    
            <?php echo e(__('Vous êtes connecté !')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app-gp\resources\views/dashboards/admins/profile.blade.php ENDPATH**/ ?>