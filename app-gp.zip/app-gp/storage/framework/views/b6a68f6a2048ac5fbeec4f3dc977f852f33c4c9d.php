<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo $__env->yieldContent('title', config('app.name')); ?></title>
        <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
        <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
    </head>
    <body>
        <header class="bg-gradient-to-r from-yellow-300 to-yellow-500 text-center px-6 py-4">
            <nav class="md:flex md:justify-between md:items-center inline">
                <?php if(auth()->guard()->check()): ?> 
                    <div>
                        <a class="text-sm font-semibold uppercase" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(Auth::user()->name); ?>

                        </a>
                    </div>
                    <div class="mt-8 md:mt-0 inline">
                        <div class="text-xs font-semibold text-white " aria-labelledby="navbarDropdown">
                            <?php echo $__env->yieldContent('nav'); ?>

                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </nav>
        </header>
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\app-gp\resources\views/layouts/app.blade.php ENDPATH**/ ?>