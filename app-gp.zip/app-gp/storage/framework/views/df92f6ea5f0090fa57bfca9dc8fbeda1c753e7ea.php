

<?php $__env->startSection('title', 'Projet | '.config('app.name')); ?>

<?php $__env->startSection('nav'); ?>
    <a href="/admin/dashboard" class="dropdown-item mr-2 ml-2">    
        <?php echo e(__('Tables de bord')); ?>

    </a>
    <a class="dropdown-item mr-2 ml-2" href="/etude">
        <?php echo e(__('Liste des études')); ?>

    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="relative w-full h-full my-5">
        <h1 class="text-3xl font-serif tracking-tighter mb-5">Liste des projets en cours</h1>
        <table class="ml-2 table-fixed ">
            <thead class="bg-yellow-500 ">
                <th class="border-2 border-white w-1/4 ">Nom</th>
                <th class="border-2 border-white w-1/4">Wilaya</th>
                <th class="border-2 border-white w-1/4">Prestataire</th>
                <th class="border-2 border-white w-1/2">Description</th>
                
            </thead>
            <tbody>
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <tr>
                        <td class="text-center border-2 border-gray-300 w-1/4 ">
                            <a href="/projects/<?php echo e($project->nom); ?>"><?php echo e($project->nom); ?></a>
                        </td>
                        <td class="text-center border-2 border-gray-300 w-1/4 ">
                            <a href="/region/<?php echo e($project->region->id); ?>"><?php echo e($project->region->wilaya); ?></a>
                        </td>
                        <td class="text-center border-2 border-gray-300 w-1/4 ">
                            <a href="/prestataire/<?php echo e($project->prestataire->id); ?>"><?php echo e($project->prestataire->nom); ?></a>
                        </td>
                        <td class="border-2 border-gray-300 w-1/4 "> <?php echo e($project->description); ?></td>
                        
                    </tr>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app-gp\resources\views/projects.blade.php ENDPATH**/ ?>