<?php $__env->startSection('title', config('app.name')); ?>


<?php $__env->startSection('content'); ?>

    <img src="<?php echo e(asset('img/sonatrach.png')); ?>" alt="SONATRACH" class="my-12 rounded shadow-md " >
    <h1 class="my-5 text-5xl font-semibold text-yellow-300 via-yellow-50">Bienvenue<h1>
    <p class="text-2xl tracking-wide text-gray-800 mb-4">  <?php echo e(date('d M y')); ?>   <?php echo e(date('H:i')); ?></p>
    <?php if(Route::has('login')): ?>
        <div class="mt-10 justify-center items-center">
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(url('/home')); ?>" class="mx-16 px-4 py-2 flex-grow w-20 rounded-lg bg-gradient-to-r from-yellow-400 to-yellow-600 text-white text-xl font-bold">&#9655;</a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="mx-8 px-4 py-2 flex-grow w-20 rounded-lg bg-gradient-to-r from-yellow-400 to-yellow-600 text-white text-lg font-medium">Connexion</a>
               
            <?php endif; ?>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<!--<?php if(Route::has('login')): ?>
        <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(url('/home')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Home</a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Log in</a>
                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>" class="ml-4 text-sm text-gray-700 dark:text-gray-500 underline">Register</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
     <?php endif; ?>-->
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app-gp\resources\views/welcome.blade.php ENDPATH**/ ?>