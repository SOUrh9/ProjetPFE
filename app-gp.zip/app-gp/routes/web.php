<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ManagerController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\ExperienceController;
use App\Http\Controllers\EtudeController;
use Illuminate\Support\Facades\Auth;
use App\Models\Project;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');


/********** AJOUT PROJET **********/ 
Route::get('admin/create',[App\Http\Controllers\ProjectController::class, 'create'])->middleware('isAdmin');
Route::post('admin',[App\Http\Controllers\ProjectController::class, 'store'])->middleware('isAdmin');


/********** AJOUT RXPERIENCE **********/ 
Route::get('user/create',[App\Http\Controllers\ExperienceController::class, 'create'])->middleware('isUser');
Route::post('user',[App\Http\Controllers\ExperienceController::class, 'store'])->middleware('isUser');



/********** ROUTE PROJET **********/   
Route::get('/project', [App\Http\Controllers\ProjectController::class, 'index'])->name('project');
Route::get('/projects/{project:nom}',[App\Http\Controllers\ProjectController::class, 'show']);



/********** ROUTE ETUDE **********/
Route::get('/etude', [App\Http\Controllers\EtudeController::class, 'index'])->name('etude');
Route::get('/etudes/{etude:nom}',[App\Http\Controllers\EtudeController::class, 'show']);


Route::get('regions/{region:nom}', function (Region $region){
    return  view('projects', [
        'projects' => $region->projects,
        
    ]);
});

/*Route::get('regions/{region}', function (Region $region){
    return  view('etudes', [
        'etudes' => $region->etudes
    ]);
});*/


Route::middleware(['middleware'=>'PreventBackHistory'])->group(function(){
    Auth::routes();
});






Route::group(['prefix'=>'admin', 'middleware'=>['isAdmin', 'auth', 'PreventBackHistory']], function(){
    Route::get('dashboard',[AdminController::class, 'index'])->name('admin.dashboard');
    Route::get('profile',[AdminController::class, 'profile'])->name('admin.profile');
    Route::get('register',[AdminController::class, 'register'])->name('admin.register');   
});


Route::group(['prefix'=>'user', 'middleware'=>['isUser', 'auth', 'PreventBackHistory']], function(){
    Route::get('dashboard',[UserController::class, 'index'])->name('user.dashboard');
    Route::get('profile',[UserController::class, 'profile'])->name('user.profile');
});


Route::group(['prefix'=>'manager', 'middleware'=>['isManager', 'auth', 'PreventBackHistory']], function(){
    Route::get('dashboard',[ManagerController::class, 'index'])->name('manager.dashboard');
    Route::get('profile',[ManagerController::class, 'profile'])->name('manager.profile');
});



