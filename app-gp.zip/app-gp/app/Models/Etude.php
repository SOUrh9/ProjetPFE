<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Etude extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function region(){
        return $this->belongsTo(Region::class);
    }

    public function prestataire(){
        return $this->belongsTo(Prestataire::class);
    }

    public function scopeFilter($query, array $filters)
    {
        $query->when($filters['search']     ??  false, function($query, $search){
            $query
                    ->where('nom','like', '%' .request('search'). '%')
                    ->orwhere('type','like', '%' .request('search'). '%');
        });
    }
}
