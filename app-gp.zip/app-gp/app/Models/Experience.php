<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Experience extends Model
{
    use HasFactory;
    protected $fillable = ['experience', 'user_id'];

    

    /*protected $with = ['author'];

    public function author()
    {
        return $this->belongsTo(User::class, 'user_id');
    }*/

}
