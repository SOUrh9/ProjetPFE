<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    use HasFactory;

    protected $guarded = [];

    protected $fillable = ['nom', 'description', 'prestataire_id', 'region_id', 'date-debut', 'date-fin', 'type'];

    public function region(){
        return $this->belongsTo(Region::class);
    }

    public function prestataire(){
        return $this->belongsTo(Prestataire::class);
    }


    public function scopeFilter($query, array $filters)
    {
        $query->when($filters['search']     ??  false, function($query, $search){
            $query
                    ->where('nom','like', '%' . $search . '%')
                    ->orwhere('description','like', '%' . $search . '%');
        });
    }

    
}
