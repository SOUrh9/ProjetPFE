<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Models\User;    
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Validator;


class AdminController extends Controller
{
    function index(){
        return view ('dashboards.admins.index');
    }


    function profile(){
        return view ('dashboards.admins.profile');
    }
    
    public function register(){
        return view('dashboards.admins.register');
    }
    
}
