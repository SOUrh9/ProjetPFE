<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Project;
use App\Models\Region;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class ProjectController extends Controller
{
    public function index(){
        return view('projects', [
            'projects' => Project::latest()->filter(request(['search']))->get(),
            'regions' =>Region::all()
        ]);
    }

    public function show(Project $project){
        return view('project', [
            'project' => $project
        ]);
    }

    public function create(){
        return view('dashboards.admins.create');
    }

    public function store(){
        $attributes = request()->validate([
            'nom' => 'required',
            'description' => ['required', Rule::unique('projects', 'description')],
            'type' => 'required',
            'date_debut' => 'required',
            'date_fin' => 'required',
            'region_id' => ['required', Rule::exists('regions', 'id')],
            'prestataire_id' => ['required', Rule::exists('prestataires', 'id')],
        ]);


        $project = new Projec($attributes); 

        if($user->save()){
            return redirect()->back()->with('success','Le projet a été crée ');
        }else{
            return redirect()->back()->with('error','Echec de création du projet ');
        }
    }

    
}
