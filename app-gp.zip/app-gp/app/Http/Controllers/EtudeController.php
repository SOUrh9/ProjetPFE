<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Etude;
use App\Models\Region;

class EtudeController extends Controller
{
    public function index(){
        return view('etudes', [
            'etudes' => Etude::latest()->filter(request(['search']))->get(),
            'regions' =>Region::all()
        ]);
    }

    public function show(Etude $etude){
        return view('etude', [
            'etude' => $etude
        ]);
    }

    
}
