<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Experience;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;


class ExperienceController extends Controller
{

    public function create(){
        return view('dashboards.users.create');
    }

    public function store(){
        $attributes = request()->validate([
            'experience' => ['required', Rule::unique('experiences', 'experience')],
        ]);

        auth()->user()->experiences()->create($attributes);

        return redirect('/');
    }

   
}
